package com.bramha;

public abstract class instrument {
	public abstract void Play();

}
