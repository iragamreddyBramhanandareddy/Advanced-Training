package com.bramha.rectangular;

import java.util.Scanner;

public class TestRectangle {
	public static int length;
	public static int breadth;
	public static int area;
public static void main(String[] args) {
	TestRectangle tr=new TestRectangle();
	Scanner sc=new Scanner (System.in);
	System.out.println("enter lenth and breadth for resctangle 1:  ");
	tr.length=sc.nextInt();
	tr.breadth=sc.nextInt();
	tr.area=length*breadth;
	System.out.println("Area of the Recatngle 1: "+tr.area);
	
	//second object
	TestRectangle tr2=new TestRectangle();
	Scanner sc2=new Scanner (System.in);
	System.out.println("enter lenth and breadth for resctangle 2:  ");
	tr2.length=sc.nextInt();
	tr2.breadth=sc.nextInt();
	tr2.area=length*breadth;
	System.out.println("Area of the Recatngle 2: "+tr2.area);
	//3rd Object
	TestRectangle tr3=new TestRectangle();
	Scanner sc3=new Scanner (System.in);
	System.out.println("enter lenth and breadth for resctangle 3:  ");
	tr3.length=sc.nextInt();
	tr3.breadth=sc.nextInt();
	tr3.area=length*breadth;
	System.out.println("Area of the Recatngle 3: "+tr3.area);
	//Fourth Object
	TestRectangle tr4=new TestRectangle();
	Scanner scan=new Scanner (System.in);
	System.out.println("enter lenth and breadth for resctangle 4:  ");
	tr4.length=sc.nextInt();
	tr4.breadth=sc.nextInt();
	tr4.area=length*breadth;
	System.out.println("Area of the Recatngle 4: "+tr4.area);
	//Fifth Object
	TestRectangle tr5=new TestRectangle();
	Scanner sca=new Scanner (System.in);
	System.out.println("enter lenth and breadth for resctangle 1:  ");
	tr5.length=sc.nextInt();
	tr5.breadth=sc.nextInt();
	tr5.area=length*breadth;
	System.out.println("Area of the Recatngle 5: "+tr5.area);
	
}
}
