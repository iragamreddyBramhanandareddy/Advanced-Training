package com.bramha.rectangular;

import java.util.Scanner;

public class Rectangle {
	int length;
	int breadth;
	int area;
	int perimeter;
	void input() {
		Scanner in=new Scanner(System.in);
		System.out.println("Enter length of Rectangle:  ");
		length =in.nextInt();
		System.out.println("Enter Breadth of rectangle:  ");
		breadth =in.nextInt();
	}
	void calculate () {
		area=length *breadth;
		perimeter= 2*(length+breadth);
		
	}
	void display() {
		System.out.println("Area of the Rectangle= " +area);
		System.out.println("perimeter of Rectangle="+ perimeter);
		
	}
	public static void main(String[] args) {
		Rectangle rec=new Rectangle();
		rec.input();
		rec.calculate();
		rec.display();
	}

}
