package com.bramha;

public class medicine {
	
		public void displayLabel()
		{
		System.out.println("Company : pharmaceutical");
		System.out.println("Address : America");
		}
		}
		class Tablet extends medicine
		{
		public void displayLabel()
		{
		System.out.println("store in a cool dry place");
		}
		}
		class Syrup extends medicine
		{
		public void displayLabel()
		{
		System.out.println("Consumption as directed by the physician");
		}
		}
		class ointment extends medicine
		{
		public void displayLabel()
		{
		System.out.println("for external use only");
		}
		

}
