package com.bramha;

class ThreadA extends Thread{
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println("FromThread A with i= "+ -1*i);
		}
		System.out.println("Exiting from Thread A.........");
	}
}
class ThreadB extends Thread{
	public void run() {
		for(int j=1;j<=5;j++) {
			System.out.println("FromThread B with j= "+ -1*j);
			
		}
		System.out.println("Exiting from Thread B.........");	
	}
}

public class textfile {
	public static void main(String[] args) {
		ThreadA a=new ThreadA();
		ThreadB b=new ThreadB();
		a.start();
		b.start();
		System.out.println("MultiThreading is Over....");
		
	}

}
class Account{
	public int balance;
	public int accountNo;
	void displayBalance() {
		System.out.println("Account No:"+accountNo+"Balance:"+balance);
		
	}
	synchronized void deposit(int amount ) {
		balance=balance+amount;
		System.out.println(amount+"is Deposited");
		displayBalance();
		
	}
	synchronized void Withdraw(int amount ) {
		balance=balance-amount;
		System.out.println(amount+"is Deposited");
		displayBalance();
	}

	class TransactionDeposit implements Runnable{
		int amount;
		Account accountX;
		TransactionDeposit(Account X, int amount){
			accountX= X;
			this.amount=amount;
			new Thread(this).start();
			
			
		}
		public void run() {
			accountX.deposit(amount);
			
		}
		
	}
	class TransactionWithdraw implements Runnable{
		int amount;
		Account accounty;
	
	TransactionWithdraw(Account y,int amount) {
		Account Y =y;
		this.amount=amount;
		new Thread(this).start();
		
	}
	public void run() {
		accounty.Withdraw(amount);
	}
	
		
	}
	class Demo1{
	public void main(String[] args) {
		Account ABC= new Account();
		ABC.balance=1000;
		ABC.accountNo=1111;
		TransactionDeposit t1;
		TransactionDeposit t2;
		t1=new TransactionDeposit(ABC,500);
		t1=new TransactionDeposit(ABC,900);
	}
}
}
