package com.brahmi.order;

public class CreateException extends Exception {

}
