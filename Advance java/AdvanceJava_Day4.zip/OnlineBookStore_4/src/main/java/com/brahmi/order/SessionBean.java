package com.brahmi.order;

public interface SessionBean {

}
