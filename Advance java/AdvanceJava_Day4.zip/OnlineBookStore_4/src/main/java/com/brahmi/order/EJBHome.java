package com.brahmi.order;

public interface EJBHome {

}
