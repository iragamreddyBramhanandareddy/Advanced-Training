package javax.ejb;

public class EJBHome {

}
