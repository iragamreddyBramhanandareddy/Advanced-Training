CREATE DATABASE bookstore ;
use bookstore ;
CREATE TABLE `books` (
  `Book_id` varchar(10) NOT NULL,
  `Book_name` varchar(50) NOT NULL,
  `Auther` varchar(20) NOT NULL,
  `Price` double NOT NULL,  
  constraint pk1 primary key (Book_id) 
);
select * from books;
 insert into books  values ( ' 1 ', 'Let Us C' , 'RD hello ' , 200.00 ) ;
 insert into books  values ( ' 2 ', 'Thinking in Java' , 'Thinking in Java'  , 300.00 ) ;
 insert into books  values ( ' 3 ', 'Aptitude' , 'RS.Agarwal' , 250.00 ) ;
 insert into books  values ( ' 4 ', 'Head First C' , 'Andrew Stellman ' , 400.00 ) ;
 insert into books  values ( ' 5', 'What is HTML5 ?' , 'Brett Mclaughlin ' , 300.00 ) ;
 insert into books  values ( ' 6 ', 'HTML in Action' , 'Joe Lennon ' , 569.00 ) ;
 insert into books  values ( ' 7 ', 'OOP with C++' , 'Balagurusamy ' , 308.00 ) ;
 insert into books  values ( ' 8 ', 'C++ : The Complete Reference' , 'Herbert Schildt ' , 532.00 ) ;
 insert into books  values ( ' 9 ', 'Head First SQl' , 'Lynn Beighley ' , 450.00 ) ;
 insert into books  values ( ' 10 ', 'SQL : The Complete References' , ' James Groff ' , 667.00 ) ;

CREATE TABLE `Users` (
  `first_name` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `registration_date` date NOT NULL
);
CREATE TABLE `order_details` (
  `Order_Id` int(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mobileno` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `Order_Date` date NOT NULL,
  `Quantity` int(11) NOT NULL,
   constraint pk1 primary key (Order_Id) 
   );
insert into  Users values ('Bramhi ' , 'Hyderabad ' , 'abc@gmail.com' ,'123456789 ', 'hello8 ' , '2010-12-01' ) ;
 insert into  Users values ('Minnu' , 'secunderabad ' , 'mfh@gmail.com' ,'8934534661' , ' minnu67' , '2020-11-17 ' ) ;
 insert into  Users values ('Aadhya ' , 'Nalgonda ' , 'riya@gmail.com' ,'9988776655' , 'aadhya@89 ' , '2021-7-07 ' ) ;
 insert into  Users values ('Honey ' , 'Hyderabad ' , 'hgf@pmo.nic.in' , '7890789090 ', '	honey_2 ' , '2022-2-08 ' ) ;
 insert into  Users values ('Milky ' , 'Warangal ' , 'mohit@gmail.com' , '9856779893' , 'mil@ky ' , '2022-11-17 ' ) ;
 select*from Users;
 




 insert into order_details  values ( '1' ,  ' Santhosh Vihar ' , '773967657' , 'Santhu ' ,'2016-11-08 ' , '3' );
 insert into order_details  values ( '2' ,  ' Radhika sagar ' , '86278651 ' , ' Radha ' , '2020-12-08 ' , '3' );
 insert into order_details  values ( '3' ,  ' Ram Gold' , '745734915' , ' Ram ' , '2002-11-02 ' , '2' );
 insert into order_details  values ( '4' ,  ' Hyderabad ' , '74512788' ,  'Brahma' , '2016-09-08 ' , '3' );
 insert into order_details  values ( '5' ,  ' Malliswari ' , '645782151' , ' Mahi ' , '2012-12-03 ' , '3' );
 insert into order_details  values ( '6' ,  ' Bangalore ' , '734568621' , 'Amit ' , '1996-12-02 ' , '2' ); 

select*from order_details;